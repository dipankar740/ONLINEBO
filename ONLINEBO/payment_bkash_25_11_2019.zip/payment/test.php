<?PHP
echo "parvej"; 
?>
<html>
	<head>
	
	</head>

<body class="text-center" id="main_body">

   <center> Please wait.... </center>
	<button id="bKash_button" disabled="disabled" >Deposit With bKash</button>


</body>

</html>